﻿-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS stringprocessingdb
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- Sử dụng cơ sở dữ liệu
USE stringprocessingdb;

-- Tạo bảng Users
CREATE TABLE Users (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(50) NOT NULL
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng History
CREATE TABLE History (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    UserId INT NOT NULL,
    InputString VARCHAR(40) NOT NULL,
    EncodedString VARCHAR(40) NOT NULL,
    InputCode VARCHAR(255),
    OutputCode VARCHAR(255),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;